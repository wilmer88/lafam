// Package hmiddleware provides common HTTP middleware.
package hmiddleware
