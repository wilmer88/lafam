// Package service provides standardized command and HTTP setup by smartly
// composing the other cmdutil packages based on environment variables.
package service
